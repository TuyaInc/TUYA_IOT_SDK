/*
aes_inf.h
Copyright(C),2018-2020, 涂鸦科技 www.tuya.comm
*/
#ifndef _AES_INF_H
#define _AES_INF_H

#include "adapter_platform.h"
#include "tuya_cloud_error_code.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef  __AES_INF_GLOBALS
    #define __AES_INF_EXT
#else
    #define __AES_INF_EXT extern
#endif

/***********************************************************
*************************micro define***********************
***********************************************************/
typedef VOID (*AES128_ECB_ENC)(IN BYTE_T *input,IN CONST BYTE_T *key,OUT BYTE_T *output);
typedef VOID (*AES128_ECB_DEC)(IN BYTE_T *input,IN CONST BYTE_T *key,OUT BYTE_T *output);
typedef VOID (*AES128_CBC_ENC_BUF)(OUT BYTE_T *output,IN BYTE_T *input,IN UINT_T length,IN CONST BYTE_T *key,IN CONST BYTE_T *iv);
typedef VOID (*AES128_CBC_DEC_BUF)(OUT BYTE_T *output,IN BYTE_T *input,IN UINT_T length,IN CONST BYTE_T *key,IN CONST BYTE_T *iv);

typedef struct {
    AES128_ECB_ENC ecb_enc;
    AES128_ECB_DEC ecb_dec;
    AES128_CBC_ENC_BUF cbc_enc;
    AES128_CBC_DEC_BUF cbc_dec;
}AES_METHOD_REG_S;

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

/***********************************************************
*  Function: aes_method_register
*  Desc:     register outer aes method to replace sdk-inner aes method.
*  Input:    aes: aes method
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes_method_register(IN CONST AES_METHOD_REG_S *aes);

/***********************************************************
*  Function: aes_method_unregister
*  Desc:     unregister outer aes method.
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
VOID aes_method_unregister(VOID);

/***********************************************************
*  Function: aes128_ecb_encode
*  Desc:     aes128 ecb-encode data WITH ADD PKCS.
*            the result data is malloc inside the func.
*  Input:    data && len: input data and data len
*  Output:   ec_data && ec_len: the encoded data
*  Input:    key: aes key
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_ecb_encode(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                              OUT BYTE_T **ec_data,OUT UINT_T *ec_len,\
                              IN CONST BYTE_T *key);

/***********************************************************
*  Function: aes128_ecb_decode
*  Desc:     aes128 ecb-decode data.
*            the result data is malloc inside the func.
*  Input:    data && len: input data and data len
*  Output:   dec_data && dec_len: the decoded data
*  Input:    key: aes key
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_ecb_decode(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                              OUT BYTE_T **dec_data,OUT UINT_T *dec_len,\
                              IN CONST BYTE_T *key);

/***********************************************************
*  Function: aes128_cbc_encode
*  Desc:     aes128 cbc-encode data.
*            the result data is malloc inside the func.
*  Input:    data && len: input data and data len
*  Input:    key: aes key
*  Input:    iv: aes iv key
*  Output:   ec_data && ec_len: the encoded data
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_cbc_encode(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                              IN CONST BYTE_T *key,IN CONST BYTE_T *iv,\
                              OUT BYTE_T **ec_data,OUT UINT_T *ec_len);

/***********************************************************
*  Function: aes128_cbc_decode
*  Desc:     aes128 cbc-decode data.
*            the result data is malloc inside the func.
*  Input:    data && len: input data and data len
*  Input:    key: aes key
*  Input:    iv: aes iv key
*  Output:   dec_data && dec_len: the decoded data
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_cbc_decode(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                              IN CONST BYTE_T *key,IN CONST BYTE_T *iv,\
                              OUT BYTE_T **dec_data,OUT UINT_T *dec_len);

/***********************************************************
*  Function: aes128_free_data
*  Desc:     free data malloced in encode/decode func.
*  Input:    data: the data need to free
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_free_data(IN BYTE_T *data);

/***********************************************************
*  Function: aes128_ecb_encode_raw
*  Desc:     aes128 ecb-encode data
*  Input:    data && len: input data and data len
*  Output:   ec_data: the encoded data
*  Input:    key: aes key
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET aes128_ecb_encode_raw(IN CONST BYTE_T *data, IN CONST UINT_T len,\
                                  OUT BYTE_T *ec_data,IN CONST BYTE_T *key);

/***********************************************************
*  Function: aes128_ecb_decode_raw
*  Desc:     aes128 ecb-decode data.
*  Input:    data && len: input data and data len
*  Output:   dec_data : the decoded data
*  Input:    key: aes key
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET aes128_ecb_decode_raw(IN CONST BYTE_T *data, IN CONST UINT_T len,\
                                  OUT BYTE_T *dec_data,IN CONST BYTE_T *key);

/***********************************************************
*  Function: aes128_cbc_encode_raw
*  Desc:     aes128 cbc-encode data.
*  Input:    data && len: input data and data len
*  Input:    key: aes key
*  Input:    iv: aes iv key
*  Output:   ec_data: the encoded data
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_cbc_encode_raw(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                                  IN CONST BYTE_T *key,IN CONST BYTE_T *iv,\
                                  OUT BYTE_T *ec_data);

/***********************************************************
*  Function: aes128_cbc_decode_raw
*  Desc:     aes128 cbc-decode data.
*  Input:    data && len: input data and data len
*  Input:    key: aes key
*  Input:    iv: aes iv key
*  Output:   dec_data: the decoded data
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
__AES_INF_EXT \
OPERATE_RET aes128_cbc_decode_raw(IN CONST BYTE_T *data,IN CONST UINT_T len,\
                                  IN CONST BYTE_T *key,IN CONST BYTE_T *iv,\
                                  OUT BYTE_T *dec_data);


#ifdef __cplusplus
}
#endif
#endif

